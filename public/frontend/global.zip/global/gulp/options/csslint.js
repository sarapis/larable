// config
var config = require('../../config.json');


module.exports = {
  csslintrc: config.source.sass + '/.csslintrc',
};
